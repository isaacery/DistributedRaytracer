/*
 * LightSource.cpp
 *
 */
#include "LightSource.h"

namespace rt{





} //namespace rt

