/*
 * AreaLight.cpp
 *
 *
 */
#include "AreaLight.h"




namespace rt{





} //namespace rt
