/*
 * BVH.h
 *
 *
 */

#ifndef BVH_H_
#define BVH_H_

#include "core/Shape.h"

namespace rt{

class BVH: public Shape{


};



} //namespace rt



#endif /* BVH_H_ */
